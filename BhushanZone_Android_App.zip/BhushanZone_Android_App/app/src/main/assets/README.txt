Bhushan.zone AI Video Studio – Demo Project

Open index.html in Chrome/Edge on a computer, or upload the folder to a web host.
The original Stitch screens are preserved inside /screens.
This is a connected UI demo. AI generation, YouTube OAuth, video processing and backend data are not yet implemented.

For an Android APK, wrap this web project with Capacitor/Android Studio or another Android WebView build workflow.
