# Bhushan.zone AI Video Studio - Android Wrapper

This Android Studio project packages the Stitch HTML demo as a WebView Android app.

## Build APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the extracted folder in Android Studio.
4. Let Gradle sync and install any requested SDK components.
5. Use Build > Build APK(s).
6. Find the debug APK in app/build/outputs/apk/debug/.

The current app is a demo UI. AI generation, YouTube login and live analytics require backend/API integration.
