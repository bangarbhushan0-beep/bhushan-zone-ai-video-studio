# Bhushan.zone AI Video Studio v3

Android WebView wrapper for the Bhushan.zone AI Video Studio UI.

This build fixes the AI Title Generator JavaScript initialization bug and improves WebView local-file interaction settings.
